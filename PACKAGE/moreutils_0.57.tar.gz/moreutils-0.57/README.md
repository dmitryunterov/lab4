### lab4 - исходники moreutils стянутые с git://git.kitenet.net/moreutils
